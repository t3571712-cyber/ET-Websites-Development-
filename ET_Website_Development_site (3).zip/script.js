const menu = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");

menu?.addEventListener("click", () => nav.classList.toggle("open"));
document.querySelectorAll(".nav a").forEach(link => {
  link.addEventListener("click", () => nav.classList.remove("open"));
});

document.getElementById("year").textContent = new Date().getFullYear();

function submitForm(event) {
  event.preventDefault();
  const name = document.getElementById("name").value.trim();
  const message = document.getElementById("form-message");
  message.textContent = `Thanks, ${name}! Your request is ready to send once a real contact method is connected.`;
  event.target.reset();
  return false;
}
