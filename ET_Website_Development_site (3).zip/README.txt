# ET Website Development

A responsive one-page business website for ET Website Development.

## Files
- index.html — main website
- styles.css — design and responsive layout
- script.js — mobile menu, year, and demo contact form

## Important before launch
1. Replace the demo contact form behavior with a real email/form service.
2. Add your real email, phone number, domain, and social links.
3. Replace sample portfolio projects with real client work when available.
4. Confirm the exact ownership/maintenance language in your client agreement.
5. Connect a domain and hosting provider.

Open `index.html` in a browser to preview it.
